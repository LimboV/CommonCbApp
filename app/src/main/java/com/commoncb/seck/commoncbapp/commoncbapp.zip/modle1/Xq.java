package com.commoncb.seck.commoncbapp.modle1;

/**
 * Created by ssHss on 2018/7/26.
 */

public class Xq {
    public String getXqName() {
        return xqName;
    }

    public void setXqName(String xqName) {
        this.xqName = xqName;
    }

    public String getXqNum() {
        return xqNum;
    }

    public void setXqNum(String xqNum) {
        this.xqNum = xqNum;
    }

    String xqName;
    String xqNum;
}
