package com.commoncb.seck.commoncbapp.modle1;

/**
 * Created by limbo on 2018/6/11.
 */

public class New_UserMsg {

    public String getUserID() {
        return UserID;
    }

    public void setUserID(String userID) {
        UserID = userID;
    }

    public String getXH() {
        return XH;
    }

    public void setXH(String XH) {
        this.XH = XH;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    String UserName;
   String UserID;
   String XH;



}
