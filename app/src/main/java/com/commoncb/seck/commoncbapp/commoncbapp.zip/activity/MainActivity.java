package com.commoncb.seck.commoncbapp.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.commoncb.seck.commoncbapp.R;
import com.commoncb.seck.commoncbapp.modle1.New_Login;
import com.commoncb.seck.commoncbapp.modle1.UpdataModle;
import com.commoncb.seck.commoncbapp.service.UpdateService;
import com.google.gson.Gson;

import java.io.File;

import butterknife.BindView;
import butterknife.ButterKnife;
import cn.pedant.SweetAlert.SweetAlertDialog;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends Activity  {
    @BindView(R.id.et_user)
    EditText et_user;
    @BindView(R.id.et_password)
    EditText et_password;
    @BindView(R.id.et_url)
    EditText et_url;
    @BindView(R.id.btn_login)
    Button btn_login;
    @BindView(R.id.btn_exit)
    ImageButton btn_exit;
    @BindView(R.id.cb_save)
    CheckBox cb_save;
    public static String url = "", user = "", password = "";
    public static New_Login muser = new New_Login();

    public static boolean upLoadAuto = true;//自动上传标志位
    public static boolean AllBtAuto = true;//蓝牙自动接收标志位
    public static boolean timeOut = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        AllBtAuto = true;
        upLoadAuto = true;
        getUpdataMsg();
        cb_save.setChecked(true);
        /**
         * 登陆
         */
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user = et_user.getText().toString().trim();
                password = et_password.getText().toString().trim();
                url = et_url.getText().toString().trim();
                if (!isLocationEnabled()){
                    new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                            .setTitleText("提示!")
                            .setContentText("请在系统设置中打开定位服务!")
                            .show();
                    return;
                }else {
                    login();
                }


            }
        });

        /**
         * 清除输入
         */
        et_user.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    et_user.clearFocus();
                }
                return false;
            }
        });
        et_password.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    et_password.clearFocus();
                }
                return false;
            }
        });

        btn_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("提示")
                        .setContentText("请确认是否要退出?")
                        .setCancelText("取消")
                        .setConfirmText("确认")
                        .showCancelButton(true)
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sweetAlertDialog) {
                                Log.d("limboV", "sure");
                                sweetAlertDialog.cancel();
                                finish();
                            }
                        })
                        .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                Log.d("limboV", "cancel");
                               /* new SweetAlertDialog(MainActivity.this, SweetAlertDialog.ERROR_TYPE)
                                        .setTitleText("取消!")
                                        .setContentText("你已经取消退出!")
                                        .show();*/
                                sDialog.cancel();
                            }
                        }).show();
            }
        });
        loadMsg();

        Drawable drawable = getResources().getDrawable(R.drawable.login_user);
        drawable.setBounds(0, 0, 30, 30);
        et_user.setCompoundDrawables(drawable, null, null, null);
        drawable = getResources().getDrawable(R.drawable.login_pass);
        drawable.setBounds(0, 0, 30, 30);
        et_password.setCompoundDrawables(drawable, null, null, null);
        drawable = getResources().getDrawable(R.drawable.login_http);
        drawable.setBounds(0, 0, 30, 30);
        et_url.setCompoundDrawables(drawable, null, null, null);
    }

    @Override
    public void onBackPressed() {
        btn_exit.performClick();
    }

    @Override
    protected void onDestroy() {
        upLoadAuto = false;
        AllBtAuto = false;
        super.onDestroy();
    }

    /**
     * 使用SharePreferences保存用户信息
     */
    public void saveMsg(String username, String password, String http) {

        SharedPreferences.Editor editor = getSharedPreferences("user_msg", MODE_PRIVATE).edit();
        editor.putString("username", username);
        editor.putString("password", password);
        editor.putString("http", http);
        editor.commit();
    }


    /**
     * 加载用户信息
     */

    public void loadMsg() {
        SharedPreferences pref = getSharedPreferences("user_msg", MODE_PRIVATE);
        et_user.setText(pref.getString("username", ""));
        et_password.setText(pref.getString("password", ""));
        et_url.setText(pref.getString("http", ""));
        et_url.setText("http://211.143.169.106:6050/CbService.asmx");//泉州
//        et_url.setText("http://211.143.169.106:6050/TestPhoneService/CbService.asmx");//泉州测试
//        et_url.setText("http://192.168.1.236:85/Reading/CbService.asmx");//测试
//        et_url.setText("http://192.168.1.236:1234/CbService.asmx");//测试
//        et_url.setText("http://www.seck.com.cn:85/Reading/CbService.asmx");//测试
        et_url.setVisibility(View.GONE);
    }

    /**
     * 登陆验证
     */
    private void login() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    OkHttpClient client = new OkHttpClient();//创建OkHttpClient对象
                    Request request = new Request.Builder()
                            .url(url + "/GetXhs?UserID=" + user + "&Password=" + password)//请求接口。如果需要传参拼接到接口后面。
                            //                            .url("http://www.baidu.com")//请求接口。如果需要传参拼接到接口后面。
                            .build();//创建Request 对象
                    Response response = null;
                    response = client.newCall(request).execute();//得到Response 对象
                    if (response.isSuccessful()) {
                        Log.d("limboV", "response.code()==" + response.code());
                        Log.d("limboV", "response.message()==" + response.message());
                        //                        Log.d("limboV", "res==" + response.body().string());
                        //此时的代码执行在子线程，修改UI的操作请使用handler跳转到UI线程。
                        String responseX = response.body().string().replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");
                        responseX = responseX.replace("<string xmlns=\"http://tempuri.org/\">", "");
                        responseX = responseX.replace("</string>", "");
                        Log.d("limbo", responseX);
                        Gson gson = new Gson();//使用Gson解析
                        New_Login muser = gson.fromJson(responseX, New_Login.class);
                        Message message = new Message();
                        message.what = 0x00;
                        message.obj = muser;
                        handler.sendMessage(message);
                    } else {
                        Message message = new Message();
                        message.what = 0x99;
                        handler.sendMessage(message);
                    }
                } catch (Exception e) {
                    Log.d("limbo", e.toString());
                    Message message = new Message();
                    message.what = 0x99;
                    handler.sendMessage(message);

                }
            }
        }).start();
    }

    /**
     * 更新情况获取
     */
    private void getUpdataMsg() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    OkHttpClient client = new OkHttpClient();//创建OkHttpClient对象
                    Request request = new Request.Builder()
                            .url("http://114.215.237.235:88/version/Service1.asmx/getVersion")//请求接口。如果需要传参拼接到接口后面。
                            .build();//创建Request 对象
                    Response response = null;
                    response = client.newCall(request).execute();//得到Response 对象
                    if (response.isSuccessful()) {
                        Log.d("limboV", "response.code()==" + response.code());
                        Log.d("limboV", "response.message()==" + response.message());
                        //                        Log.d("limboV", "res==" + response.body().string());
                        //此时的代码执行在子线程，修改UI的操作请使用handler跳转到UI线程。
                        String responseX = response.body().string().replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");
                        responseX = responseX.replace("<string xmlns=\"http://tempuri.org/\">", "");
                        responseX = responseX.replace("</string>", "");
                        Log.d("limbo", responseX);
                        Gson gson = new Gson();//使用Gson解析
                        UpdataModle updataModle = gson.fromJson(responseX, UpdataModle.class);
                        Message message = new Message();
                        message.what = 0x01;
                        message.obj = updataModle;
                        handler.sendMessage(message);
                    } else {
                        /*Message message = new Message();
                        message.what = 0x99;
                        handler.sendMessage(message);*/
                    }
                } catch (Exception e) {
                    Log.d("limbo", e.toString());
                    /*Message message = new Message();
                    message.what = 0x99;
                    handler.sendMessage(message);*/
                }
            }
        }).start();

    }

    private Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0x00:
                    muser = (New_Login) msg.obj;
                    if (muser.getFlag().equals("success") && muser != null) {
                        Log.d("limbo", "success:userid=" + muser.getDatas().get(0).getUserID());
                        if (cb_save.isChecked()) {
                            Log.d("limbo", "save");
                            saveMsg(user, password, url);
                        } else {
                            Log.d("limbo", "not save");
                            //                            saveMsg(user, password, "");
                        }

                        Intent i = new Intent(MainActivity.this, MenuActivity.class);
                        startActivity(i);
                    } else {
                        Toast.makeText(MainActivity.this, "无用户信息", Toast.LENGTH_LONG).show();
                        Log.d("limbo", "fail");
                    }
                    break;

                //更新app
                case 0x01:
                    final UpdataModle updataModle = (UpdataModle) msg.obj;
                    String note = updataModle.getUpgradeinfo();//更新备注
                    if (updataModle.getAppname().equals("泉州自来水有限公司智能抄表系统")) {
                        int versionCode = MenuActivity.getVersionCode(MainActivity.this);
                        if (versionCode < Integer.parseInt(updataModle.getServerVersion())) {
                            //是否需要更新
                            if (updataModle.getLastForce().equals("1")) {
                                //强制升级
                            } else {
                                //不强制升级
                            }
                            new SweetAlertDialog(MainActivity.this, SweetAlertDialog.WARNING_TYPE)
                                    .setTitleText("有新版本")
                                    .setContentText("更新日志:" + note + "\n是否需要升级?")
                                    .setCancelText("取消")
                                    .setConfirmText("升级")
                                    .showCancelButton(true)
                                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(SweetAlertDialog sweetAlertDialog) {
                                            Log.d("limboV", "sure");
                                            sweetAlertDialog.cancel();

                                            Intent mIntent = new Intent(MainActivity.this, UpdateService.class);
                                            mIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                            //传递数据
                                            mIntent.putExtra("appname", updataModle.getAppname());
                                            mIntent.putExtra("appurl", updataModle.getUpdateurl());
                                            MainActivity.this.startService(mIntent);
                                        }
                                    })
                                    .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                        @Override
                                        public void onClick(SweetAlertDialog sDialog) {
                                            Log.d("limboV", "cancel");
                               /* new SweetAlertDialog(MainActivity.this, SweetAlertDialog.ERROR_TYPE)
                                        .setTitleText("取消!")
                                        .setContentText("你已经取消退出!")
                                        .show();*/
                                            sDialog.cancel();
                                            clearUpateFile(MainActivity.this);
                                        }
                                    }).show();

                        }
                    }


                    break;
                case 0x99:
                    new SweetAlertDialog(MainActivity.this, SweetAlertDialog.ERROR_TYPE)
                            .setTitleText("错误")
                            .setContentText("网络异常!")
                            .show();
                    break;
                default:
                    break;
            }
        }
    };

    /**
     * 清理升级文件
     *
     * @param context
     */
    private void clearUpateFile(final Context context) {
        File updateDir;
        File updateFile;
        if (Environment.MEDIA_MOUNTED.equals(Environment
                .getExternalStorageState())) {
            updateDir = new File(Environment.getExternalStorageDirectory(), UpdataModle.downloadDir);
        } else {
            updateDir = context.getFilesDir();
        }
        updateFile = new File(updateDir.getPath(), context.getResources()
                .getString(R.string.app_name) + ".apk");
        if (updateFile.exists()) {
            Log.d("update", "升级包存在，删除升级包");
            updateFile.delete();
        } else {
            Log.d("update", "升级包不存在，不用删除升级包");
        }
    }
    public boolean isLocationEnabled() {
        int locationMode = 0;
        String locationProviders;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            try {
                locationMode = Settings.Secure.getInt(getContentResolver(), Settings.Secure.LOCATION_MODE);
            } catch (Settings.SettingNotFoundException e) {
                e.printStackTrace();
                return false;
            }
            return locationMode != Settings.Secure.LOCATION_MODE_OFF;
        } else {
            locationProviders = Settings.Secure.getString(getContentResolver(), Settings.Secure.LOCATION_PROVIDERS_ALLOWED);
            return !TextUtils.isEmpty(locationProviders);
        }
    }
}
