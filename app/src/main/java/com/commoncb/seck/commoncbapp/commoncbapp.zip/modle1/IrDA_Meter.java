package com.commoncb.seck.commoncbapp.modle1;

/**
 * Created by limbo on 2018/6/21.
 */

public class IrDA_Meter {
    String XqNum;

    public String getXqNum() {
        return XqNum;
    }

    public void setXqNum(String xqNum) {
        XqNum = xqNum;
    }

    public String getCjjNum() {
        return CjjNum;
    }

    public void setCjjNum(String cjjNum) {
        CjjNum = cjjNum;
    }

    public String getMeterNum() {
        return MeterNum;
    }

    public void setMeterNum(String meterNum) {
        MeterNum = meterNum;
    }

    String CjjNum;
    String MeterNum;
}
