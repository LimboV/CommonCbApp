package com.commoncb.seck.commoncbapp.modle1;

import java.util.List;

/**
 * Created by ssHss on 2018/7/16.
 */

public class HisDataList {
    String flag;
    List<HisMeterDataAndPicID> datas;
    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public List<HisMeterDataAndPicID> getDatas() {
        return datas;
    }

    public void setDatas(List<HisMeterDataAndPicID> datas) {
        this.datas = datas;
    }



}
