package com.commoncb.seck.commoncbapp.modle1;

/**
 * Created by ssHss on 2018/7/27.
 */

public class CntXH {
    public int getCnt() {
        return cnt;
    }

    public void setCnt(int cnt) {
        this.cnt = cnt;
    }

    public String getXH() {
        return XH;
    }

    public void setXH(String XH) {
        this.XH = XH;
    }

    int cnt;
    String XH;
}
