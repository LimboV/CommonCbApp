package com.commoncb.seck.commoncbapp.model;

/**
 * Created by limbo on 2018/5/22.
 */

public class Login {
    String flag;
    String UserId;
    public String getFlsg() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getUserId() {
        return UserId;
    }

    public void setUserId(String userId) {
        UserId = userId;
    }


}
