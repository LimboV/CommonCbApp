package com.commoncb.seck.commoncbapp.model;

/**
 * Created by ssHss on 2018/6/27.
 */

public class msg {
    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getXqnum() {
        return xqnum;
    }

    public void setXqnum(String xqnum) {
        this.xqnum = xqnum;
    }

    public String getCjjnum() {
        return cjjnum;
    }

    public void setCjjnum(String cjjnum) {
        this.cjjnum = cjjnum;
    }

    String result;
    String xqnum;
    String cjjnum;
}
