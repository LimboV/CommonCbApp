package com.commoncb.seck.commoncbapp.modle1;

/**
 * Created by limbo on 2018/2/6.
 */

public class MeterCount {
    int YCCount;
    int WCCount;
    
    public int getYCCount() {
        return YCCount;
    }

    public void setYCCount(int YCCount) {
        this.YCCount = YCCount;
    }

    public int getWCCount() {
        return WCCount;
    }

    public void setWCCount(int WCCount) {
        this.WCCount = WCCount;
    }


}
