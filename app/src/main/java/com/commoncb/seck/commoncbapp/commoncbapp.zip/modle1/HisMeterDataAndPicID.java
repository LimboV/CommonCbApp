package com.commoncb.seck.commoncbapp.modle1;

/**
 * Created by ssHss on 2018/7/16.
 */

public class HisMeterDataAndPicID {
    public String getData() {
        return Data;
    }

    public void setData(String data) {
        Data = data;
    }

    public String getDateTime() {
        return DateTime;
    }

    public void setDateTime(String dateTime) {
        DateTime = dateTime;
    }

    public String getWaterVolume() {
        return WaterVolume;
    }

    public void setWaterVolume(String waterVolume) {
        WaterVolume = waterVolume;
    }

    public String getPicID1() {
        return PicID1;
    }

    public void setPicID1(String picID1) {
        PicID1 = picID1;
    }

    public String getPicID2() {
        return PicID2;
    }

    public void setPicID2(String picID2) {
        PicID2 = picID2;
    }

    public String getPicID3() {
        return PicID3;
    }

    public void setPicID3(String picID3) {
        PicID3 = picID3;
    }

    String Data;
    String DateTime;
    String WaterVolume;
    String PicID1;
    String PicID2;
    String PicID3;

    public String getNote() {
        return Note;
    }

    public void setNote(String note) {
        Note = note;
    }

    String Note;



}
