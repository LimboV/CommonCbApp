package com.commoncb.seck.commoncbapp.utils;

import android.bluetooth.BluetoothAdapter;

/**
 *
 * 网络层，默认实现为采用蓝牙转串口进行通信。
 *
 * @author Guhong. 2012.09.02.
 *
 */
public class NetworkLayer {

	static public BluetoothAdapter adapter = null;

}
